#!/bin/bash
set -euo pipefail
 
# ---- REGION SELECTION MODULE ----
region_options=(
    "ap-south-1"
    "ap-south-2"
    "us-east-1"
    "us-east-2"
    "eu-central-1"
    "eu-west-2"
)
 
select_regions() {
    echo "Select AWS regions by entering numbers separated by space (e.g. 1 3 5). Press Enter to select none:"
    for i in "${!region_options[@]}"; do
        printf "%d. %s\n" $((i+1)) "${region_options[$i]}"
    done
    read -p "Your selection: " -a selections
    selected_regions=()
    for sel in "${selections[@]}"; do
        if [[ "$sel" =~ ^[0-9]+$ ]] && (( sel >= 1 && sel <= ${#region_options[@]} )); then
            selected_regions+=("${region_options[$((sel-1))]}")
        else
            echo "Warning: Invalid selection '$sel' ignored."
        fi
    done
    cloud_region="${AWS_REGION:-}"
    if [[ -n "$cloud_region" ]]; then
        if [[ ! " ${selected_regions[@]} " =~ " $cloud_region " ]]; then
            selected_regions+=("$cloud_region")
        fi
    fi
    echo -e "Regions selected: ${selected_regions[*]}\n"
}


print_compliance_status() {
    local TSV="$1"
    local DATE="$date_filter"
    local REGION="$region"
 
    local COMPLIANT_INSTANCES NONCOMPLIANT_INSTANCES
 
    COMPLIANT_INSTANCES=$(echo "$TSV" | awk -F"\t" '$2=="COMPLIANT" {print $1}')
    NONCOMPLIANT_INSTANCES=$(echo "$TSV" | awk -F"\t" '$2=="NON_COMPLIANT" {print $1}')
 
    echo -e "\nCOMPLIANT INSTANCES $DATE $REGION"
    echo "$COMPLIANT_INSTANCES"
    echo "NON COMPLIANT INSTANCES $DATE $REGION"
    echo -e "$NONCOMPLIANT_INSTANCES\n"
}


output_in_table(){
local TSV="$1"
local REGION="$region"
echo -e "\nInstanceId_$REGION\t\tStatus\t\tExecutionTime"
if [[ -n "$TSV" ]]; then
  echo "$TSV" | sort -t$'\t' -k2,2
  TOTAL=$(echo "$TSV" | wc -l | tr -d ' ')
else
  TOTAL=0
fi
echo -e "Total\t$TOTAL\n"
}




# ------------- SCRIPT BEGINS -----------------
select_regions
regions=("${selected_regions[@]}")
if [[ ${#regions[@]} -eq 0 ]]; then
    echo "No regions selected or detected. Exiting."
    exit 1
fi
 
# Date prompt (YYYY-MM-DD)
read -p "Enter compliance date (YYYY-MM-DD) [default: today]: " input_date
if [[ -z "$input_date" ]]; then
    input_date=$(date +%Y-%m-%d)
fi

# Validate date format
if [[ ! "$input_date" =~ ^[0-9]{4}-[0-9]{2}-[0-9]{2}$ ]]; then
    echo "ERROR: Date format must be YYYY-MM-DD"
    exit 1
fi
 
#date_filter="$input_date"
date_filter="${1:-$input_date}"



echo -e "\nSelect the desired output format:"
echo "1. Tabular format displaying Instance IDs, Status, and Date."
echo "2. List of Instance IDs grouped by compliance status."
read -p "Enter your selection (1 or 2): " output_selection
 
if [[ "$output_selection" != "1" && "$output_selection" != "2" ]]; then
    exit 1
fi


declare -A compliant_ids
declare -A noncompliant_ids
 
for region in "${regions[@]}"; do

	TSV_OUTPUT="$(
		aws ssm list-resource-compliance-summaries \
			--region "$region" \
			--filters "Key=ComplianceType,Values=Patch,Type=EQUAL" \
			--no-cli-pager \
			--output text \
			--query "ResourceComplianceSummaryItems[?starts_with(ExecutionSummary.ExecutionTime, \`${date_filter}\`)][ResourceId,Status,ExecutionSummary.ExecutionTime]" \
		|| true
	)"
	


if [[ "$output_selection" == "1" ]]; then
    output_in_table "$TSV_OUTPUT"

elif [[ "$output_selection" == "2" ]]; then
    TSV_OUTPUT_SORTED=$(echo "$TSV_OUTPUT" | sort -t$'\t' -k3,3) && print_compliance_status "$TSV_OUTPUT_SORTED"

else
    echo "Invalid selection. Please enter 1 or 2."
fi


done
 
 
