#!/bin/bash
 
region_options=(
    "ap-south-1"
    "ap-south-2"
    "us-east-1"
    "us-east-2"
    "eu-central-1"
    "eu-west-2"
)
 
select_regions() {
    echo "Select AWS regions by entering numbers separated by space (e.g. 1 3 5). Press Enter to select none:"
    for i in "${!region_options[@]}"; do
        printf "%d. %s\n" $((i+1)) "${region_options[$i]}"
    done
    read -p "Your selection: " -a selections
    selected_regions=()
    for sel in "${selections[@]}"; do
        if [[ "$sel" =~ ^[0-9]+$ ]] && (( sel >= 1 && sel <= ${#region_options[@]} )); then
            selected_regions+=("${region_options[$((sel-1))]}")
        else
            echo "Warning: Invalid selection '$sel' ignored."
        fi
    done
    cloud_region="${AWS_REGION}"
    if [[ -n "$cloud_region" ]]; then
        if [[ ! " ${selected_regions[@]} " =~ " $cloud_region " ]]; then
            selected_regions+=("$cloud_region")
        fi
    fi
    echo "Regions selected: ${selected_regions[*]}"
}
 
read_inputs() {
    local prompt="$1"
    local -n result_array=$2
    echo "$prompt (enter multiple lines, press Ctrl+D when done):"
    result_array=()
    while read -r line; do
        [[ -n "$line" ]] && result_array+=("$line")
    done
}
 
ssm_script='ll #yum update -y --exclude mysql*,httpd*,apache*,chrome*,chromium*,jenkins*,docker*,tomcat*'
 
 
select_regions
regions=("${selected_regions[@]}")
if [[ ${#regions[@]} -eq 0 ]]; then
    echo "No regions selected or detected. Exiting."
    exit 1
fi
 
echo "====================================="
echo "The following command will be sent to selected instances:"
echo "$ssm_script"
echo "Press Enter to continue..."
read -r -n 1 key
if [[ "$key" != "" ]]; then
    echo -e "\nOperation cancelled."
    exit 1
fi
echo
 
read_inputs "Enter instance IDs" instance_ids
if [[ ${#instance_ids[@]} -eq 0 ]]; then
    echo "No instance IDs entered. Exiting."
    exit 1
fi
 
declare -A instance_found_any
 
echo "Sending SSM commands..."
for region in "${regions[@]}"; do
    echo "$region"
    for instance_id in "${instance_ids[@]}"; do
        # Single AWS CLI call to extract state and platform in one go
        desc_output=$(aws ec2 describe-instances \
            --instance-ids "$instance_id" \
            --region "$region" \
            --query 'Reservations[0].Instances[0].[State.Name,Platform]' \
            --output text 2>/dev/null)
        state=$(echo "$desc_output" | awk '{print $1}')
        platform=$(echo "$desc_output" | awk '{print $2}')
 
        if [[ "$state" == "None" || -z "$state" ]]; then
            continue
        fi
 
        instance_found_any["$instance_id"]=1
 
        if [[ "$platform" == "windows" ]]; then
            echo "$instance_id  error: instance os not Linux"
            continue
        fi
 
        if [[ "$state" != "running" ]]; then
            echo "$instance_id  error: instance not running"
            continue
        fi
 
        command_id=$(aws ssm send-command \
            --region "$region" \
            --instance-ids "$instance_id" \
            --document-name "AWS-RunShellScript" \
			--parameters commands="['$ssm_script']" \
            --query "Command.CommandId" \
            --output text 2>&1)
        if [[ ! "$command_id" =~ ^[0-9a-fA-F-]{36}$ ]]; then
            echo "$instance_id  error: unable to send ssm command"
        else
            echo "$instance_id  $command_id"
        fi
    done
    echo
done
 
# After all regions, show IDs not found anywhere
not_found=()
for instance_id in "${instance_ids[@]}"; do
    if [[ -z "${instance_found_any[$instance_id]}" ]]; then
        not_found+=("$instance_id")
    fi
done
if [[ ${#not_found[@]} -gt 0 ]]; then
    echo "Instance IDs not found in any selected region:"
    for nf in "${not_found[@]}"; do
        echo "$nf"
    done
fi
 