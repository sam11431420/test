#!/bin/bash
 
# ---- REGION SELECTION MODULE ----
region_options=(
    "ap-south-1"
    "ap-south-2"
    "us-east-1"
    "us-east-2"
    "eu-central-1"
    "eu-west-2"
)
 
select_regions() {
    echo "Select AWS regions by entering numbers separated by space (e.g. 1 3 5). Press Enter to select none:"
    for i in "${!region_options[@]}"; do
        printf "%d. %s\n" $((i+1)) "${region_options[$i]}"
    done
    read -p "Your selection: " -a selections
    selected_regions=()
    for sel in "${selections[@]}"; do
        if [[ "$sel" =~ ^[0-9]+$ ]] && (( sel >= 1 && sel <= ${#region_options[@]} )); then
            selected_regions+=("${region_options[$((sel-1))]}")
        else
            echo "Warning: Invalid selection '$sel' ignored."
        fi
    done
    cloud_region="${AWS_REGION:-}"
    if [[ -n "$cloud_region" ]]; then
        if [[ ! " ${selected_regions[@]} " =~ " $cloud_region " ]]; then
            selected_regions+=("$cloud_region")
        fi
    fi
    echo "Regions selected: ${selected_regions[*]}"
}
 
read_inputs() {
    local prompt="$1"
    local -n result_array=$2
    echo "$prompt (enter multiple lines, press Ctrl+D when done):"
    result_array=()
    while read -r line; do
        [[ -n "$line" ]] && result_array+=("$line")
    done
}
 
# ---- Get Instance Name Tag ----
get_instance_name() {
    local region=$1
    local instance_id=$2
    aws ec2 describe-instances --region "$region" --instance-ids "$instance_id" \
        --query "Reservations[].Instances[].Tags[?Key=='Name'].Value | [0]" --output text 2>/dev/null
}
 
# ---- AMI BACKUP FUNCTION ----
create_ami_backup() {
  local region=$1
  local instance_id=$2
  local delete_on=$3
  local instance_name=$4
  
  ami_id=$(aws ec2 create-image --region "$region" --instance-id "$instance_id" --no-reboot --name "Backup-$instance_id-$(date +%Y%m%d%H%M%S)" --query "ImageId" --output text)
  
  # Compose Name tag value for AMI
  local ami_name_tag="${instance_name}-DeleteOn-${delete_on}"
  
  # Tag the AMI with DeleteOn and Name
  aws ec2 create-tags --region "$region" --resources "$ami_id" --tags Key=DeleteOn,Value="$delete_on" Key=Name,Value="$ami_name_tag"
  
  echo "$instance_id $ami_id Name $ami_name_tag"
}
 
check_instance_existence() {
  aws ec2 describe-instances --region "$1" --instance-ids "$2" --query "Reservations[*].Instances[*].InstanceId" --output text 2>/dev/null
}
 
# ------------- SCRIPT BEGINS -----------------
select_regions
regions=("${selected_regions[@]}")
if [[ ${#regions[@]} -eq 0 ]]; then
    echo "No regions selected or detected. Exiting."
    exit 1
fi
 
read_inputs "Enter instance IDs" instance_ids
if [[ ${#instance_ids[@]} -eq 0 ]]; then
    echo "No instance IDs entered. Exiting."
    exit 1
fi
 
read -p "Enter the DeleteOn date (MM-DD-YYYY) [default: 7 days from today]: " delete_on
if [[ -z "$delete_on" ]]; then
    delete_on=$(date -d "+7 days" +%m-%d-%Y)
    echo "No date provided, defaulting DeleteOn to $delete_on"
fi
 
declare -A instance_found
 
for region in "${regions[@]}"; do
    echo "$region"
    for instance_id in "${instance_ids[@]}"; do
        # Skip if instance already found in previous region
        if [[ "${instance_found[$instance_id]}" == "yes" ]]; then
            continue
        fi
 
        existing_instance=$(check_instance_existence "$region" "$instance_id")
        if [ -n "$existing_instance" ]; then
            instance_name=$(get_instance_name "$region" "$instance_id")
            # If no Name tag, fallback to instance ID as name
            if [[ -z "$instance_name" || "$instance_name" == "None" ]]; then
                instance_name="$instance_id"
            fi
            create_ami_backup "$region" "$instance_id" "$delete_on" "$instance_name"
            instance_found[$instance_id]="yes"
        fi
    done
    echo
done
 
# After all regions processed, print instances not found in any region
echo "Instances not found in any selected region:"
not_found=0
for instance_id in "${instance_ids[@]}"; do
    if [[ "${instance_found[$instance_id]}" != "yes" ]]; then
        echo "$instance_id"
        not_found=1
    fi
done
 
if [[ $not_found -eq 0 ]]; then
    echo "None"
fi
 